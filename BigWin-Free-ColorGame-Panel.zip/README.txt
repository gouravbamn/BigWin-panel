This is the free BigWin earning panel.
Includes: Login/Register, Game UI, Token Demo, Outcome Control.