// BigWin Logic
console.log('Game logic here');